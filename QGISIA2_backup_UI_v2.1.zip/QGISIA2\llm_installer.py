# -*- coding: utf-8 -*-
"""
Auto-installation de litellm dans un dossier vendor/ isole du plugin.

Strategie turnkey :
- Aucune dependance Docker
- Aucun venv systeme
- pip install --target qgis_plugin/vendor/ litellm + deps minimales
- sys.path prepend de vendor/ pour que les imports soient prioritaires

Compatible QGIS Python 3.9+, Windows / Linux / macOS.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import Callable, Dict, Optional

from .error_handler import plugin_logger

PLUGIN_DIR = Path(__file__).parent
VENDOR_DIR = PLUGIN_DIR / "vendor"
MARKER_FILE = VENDOR_DIR / ".installed"

# Dependances minimales. Versions epinglees pour reproductibilite commerciale.
REQUIRED_PACKAGES = [
    "litellm==1.52.0",
    "pyyaml>=6.0",
    "httpx>=0.27",
    "tiktoken>=0.7",
    "certifi>=2024.0",  # Certificats SSL pour HTTPS
]

# Version minimale de pip requise
MIN_PIP_VERSION = "21.0"

_install_lock = threading.Lock()
_install_in_progress = False


def is_vendor_ready() -> bool:
    """True si vendor/ contient une install litellm fonctionnelle."""
    if not MARKER_FILE.exists():
        return False
    try:
        ensure_vendor_on_path()
        import litellm  # noqa: F401
        return True
    except ImportError:
        return False


def ensure_vendor_on_path() -> None:
    """Prepend vendor/ au sys.path si pas deja present."""
    vendor_str = str(VENDOR_DIR)
    if VENDOR_DIR.exists() and vendor_str not in sys.path:
        sys.path.insert(0, vendor_str)


def _check_pip_version() -> tuple[bool, str]:
    """Verifie que pip est suffisamment recent."""
    try:
        import pip
        version = pip.__version__
        parts = version.split('.')
        major = int(parts[0])
        minor = int(parts[1]) if len(parts) > 1 else 0
        min_parts = MIN_PIP_VERSION.split('.')
        min_major = int(min_parts[0])
        min_minor = int(min_parts[1]) if len(min_parts) > 1 else 0
        
        if (major, minor) >= (min_major, min_minor):
            return True, version
        return False, version
    except Exception as e:
        return False, f"erreur: {e}"


def _pip_install(progress_cb: Optional[Callable[[str], None]] = None) -> Dict:
    """Execute pip install --target vendor/ REQUIRED_PACKAGES."""
    VENDOR_DIR.mkdir(parents=True, exist_ok=True)
    
    # Verif pip version
    if progress_cb:
        progress_cb("Verification de pip...")
    pip_ok, pip_ver = _check_pip_version()
    if not pip_ok:
        return {
            "success": False, 
            "error": f"pip trop ancien ({pip_ver}). Requis: {MIN_PIP_VERSION}+. Mettez a jour QGIS ou pip."
        }
    
    if progress_cb:
        progress_cb(f"pip OK ({pip_ver})")

    cmd = [
        sys.executable,
        "-m", "pip", "install",
        "--target", str(VENDOR_DIR),
        "--upgrade",
        "--no-warn-script-location",
        "--disable-pip-version-check",
        *REQUIRED_PACKAGES,
    ]

    if progress_cb:
        progress_cb(f"Telechargement de {len(REQUIRED_PACKAGES)} packages...")

    plugin_logger.info(f"Pip install vers {VENDOR_DIR}")
    try:
        creationflags = 0
        if os.name == "nt":
            creationflags = subprocess.CREATE_NO_WINDOW  # type: ignore[attr-defined]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600,  # 10 min max
            creationflags=creationflags,
        )
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Timeout pip install (>10min)"}
    except Exception as exc:  # pylint: disable=broad-except
        return {"success": False, "error": f"Echec pip: {exc}"}

    if result.returncode != 0:
        plugin_logger.error(f"pip stderr: {result.stderr[:2000]}")
        return {
            "success": False,
            "error": f"pip exit code {result.returncode}",
            "stderr": result.stderr[-2000:],
        }

    MARKER_FILE.write_text("ok", encoding="utf-8")
    ensure_vendor_on_path()
    return {"success": True, "stdout": result.stdout[-1000:]}


def install_if_needed(
    progress_cb: Optional[Callable[[str], None]] = None,
    force: bool = False,
) -> Dict:
    """
    Point d'entree unique. Idempotent, thread-safe.

    Returns:
        {success: bool, already_installed: bool, error?: str}
    """
    global _install_in_progress

    if not force and is_vendor_ready():
        return {"success": True, "already_installed": True}

    with _install_lock:
        if _install_in_progress:
            return {"success": False, "error": "Install deja en cours"}
        _install_in_progress = True

    try:
        if progress_cb:
            progress_cb("Preparation du gateway IA...")

        result = _pip_install(progress_cb=progress_cb)
        result["already_installed"] = False

        if result["success"] and progress_cb:
            progress_cb("Gateway IA pret.")

        return result
    finally:
        with _install_lock:
            _install_in_progress = False


def install_async(progress_cb: Optional[Callable[[str], None]] = None) -> threading.Thread:
    """Lance l'install en thread (non-bloquant pour QGIS UI)."""
    thread = threading.Thread(
        target=install_if_needed,
        kwargs={"progress_cb": progress_cb},
        daemon=True,
        name="GeoSylvaLLMInstaller",
    )
    thread.start()
    return thread


# Auto-ajout du vendor au sys.path des l'import du module
ensure_vendor_on_path()
